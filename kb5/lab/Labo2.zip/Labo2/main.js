window.onload = main;

function main() {
  //Ajouter heure dans la page
  document.getElementById("heure").innerHTML += new Date().toLocaleTimeString();

  //Chercher la valeur du pizza choisie et mettre l'image appropriée
  let selectPizza = document.getElementsByName("choix-pizza")[0];
  let pizzaSélectionnée = document.getElementsByName("choix-pizza")[0].value;
  document.getElementById("image-pizza").src = pizzaSélectionnée + ".png";

  //Ajouter les actions aux évènements nécessaire
  ajoutActionsÉvènements();
}

function ajoutActionImagePizza() {
  let selectPizza = document.getElementsByName("choix-pizza")[0];
  let pizzaSélectionnée = selectPizza.value;
  selectPizza.onchange = function () {
    let pizzaSélectionnée = selectPizza.value;
    document.getElementById("image-pizza").src = pizzaSélectionnée + ".png";
  }
}

function ajoutActionBorduresErreur() {
  let formulairePizza = document.forms[0];
  formulairePizza.elements["submit"].onclick = function () {
    for (let entrée of document.querySelectorAll("input[type=text], input[type=tel")) {
      if (entrée.value === "") {
        entrée.style.border = "1px solid red";
        document.getElementById("err").innerText = "Il y a des champs obligatoires vides";
      }
    }
  }
}

function ajoutActionBorduresNormale() {
  let entrées = document.querySelectorAll("input[type=text], input[type=tel]");
  let styleBordureDéfaut = entrées[0].style.border;
  for (let entrée of entrées) {
    entrée.onchange = function () {
      if (entrée.value != "")
        entrée.style.border = styleBordureDéfaut;
    }
  }
}

function ajoutActionsÉvènements() {
  ajoutActionImagePizza();
  ajoutActionBorduresErreur();
  ajoutActionBorduresNormale();

  document.getElementById("reset").onclick = function(){alert("Les champs seront réinitialisés")};
  document.getElementById("ret").onclick = function(){history.back()};
}