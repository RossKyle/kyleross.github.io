﻿/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12_ExercicesSurLesLambdas
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> liste = PeuplerListeEntiers();
            AfficherContenu(liste);

            // Trouver les éléments pairs de la liste
            // Afficher le résultat à l'aide de la fonction AfficherContenu
            AfficherContenu(liste.Where(e => e % 2 == 0));

            // Trouver les éléments plus grands ou égaux à 80
            // Afficher le résultat à l'aide de la fonction AfficherContenu
            AfficherContenu(liste.Where(e => e >= 80));
            
            // Trouver les éléments entre 60 et 90 inclusivement
            // Afficher le résultat à l'aide de la fonction AfficherContenu
            AfficherContenu(liste.Where(e => e >= 60 && e >= 90));

            // Trouver la somme de tous les éléments de la liste
            // Afficher le résultat dans la console avec Console.WriteLine  
            Console.WriteLine(liste.Sum());
            
            // Trouver la moyenne des éléments pairs de la liste
            // Afficher le résultat dans la console avec Console.WriteLine  
            Console.WriteLine(liste.Where(e => e % 2 == 0).Average());

            // --------------- Deuxième partie : en utilisant une liste de Personne
            List<Personne> listeP = PeuplerListePersonnes();
            AfficherContenu(listeP);

            // Liste des personnes qui ont moins de 40 ans
            // Afficher le résultat à l'aide de la fonction AfficherContenu
            AfficherContenu(listeP.Where(p => p.Age < 40));

            // Somme des ages de toutes les personnes
            // Afficher le résultat dans la console avec Console.WriteLine  
            Console.WriteLine(listeP.Sum(p => p.Age));
            
            // Moyenne de l'age des personnes moins de 40 ans;
            // Afficher le résultat dans la console avec Console.WriteLine  
            Console.WriteLine(listeP.Where(p => p.Age < 40).Average(p => p.Age));
        }

        static List<Personne> PeuplerListePersonnes()
        {
            const int Max = 100;
            List<Personne> liste = new List<Personne>();
            Random hasard = new Random();

            liste.Add(new Personne("Albert", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Chantal", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Catherine", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Alexandre", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Guillaume", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Pierre-Luc", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Joanie", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Victoria", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Arielle", hasard.Next(0, Max + 1)));
            liste.Add(new Personne("Sébastien", hasard.Next(0, Max + 1)));

            return liste;
        }

        static List<int> PeuplerListeEntiers()
        {
            const int POPULATION = 15;
            const int MAX = 100;
            List<int> liste = new List<int>();
            Random hasard = new Random();

            for (int i = 0; i < POPULATION; ++i)
            {
                liste.Add(hasard.Next(0, MAX + 1));
            }

            return liste;
        }

        static void AfficherContenu<T>(IEnumerable<T> liste)
        {
            foreach (T element in liste)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine(new string('-', 70));
        }
    }
}
*/
