﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12_ExercicesSurLesLambdas
{
    class Personne
    {
        public string Nom { get; private set; }
        public int Age { get; private set; }

        public Personne(string nom, int age)
        {
            Nom = nom;
            Age = age;
        }

        public override string ToString()
        {
            return Nom + ", " + Age.ToString();
        }
    }
}
