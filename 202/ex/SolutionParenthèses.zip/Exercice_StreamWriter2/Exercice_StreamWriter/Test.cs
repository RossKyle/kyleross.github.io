class Test {
	public Test(]
	{
		for (int i = 0; i < 5; ++i)
		{
			int[ tableau;
		}
}]](
