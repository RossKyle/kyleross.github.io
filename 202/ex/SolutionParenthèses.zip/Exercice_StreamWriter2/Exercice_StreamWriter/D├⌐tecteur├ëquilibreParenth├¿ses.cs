using System;
using System.Collections.Generic;
using System.Text;

namespace Exercice_StreamWriter
{
    public class DétecteurÉquilibreParenthèses
    {
        readonly (char, char)[] PairsParenthèses = new (char,char)[] {('(', ')'), ('{','}'), ('[',']')};
        private Stack<char> parenthèses;

        private Stack<char> Parenthèses
        {
            get { return parenthèses; }
            set { parenthèses = value; }
        }

        public DétecteurÉquilibreParenthèses()
        {
            Parenthèses = new Stack<char>(4);
        }

        public string Détecter(string s)
        {
            StringBuilder sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                foreach ((char, char) pair in PairsParenthèses)
                {
                    if (c == pair.Item1)
                    {
                        parenthèses.Push(c);
                        break; //Si une parenthèse ouvrante est trouvée, arrêter le deuxième foreach
                    }
                 
                    if (c == pair.Item2)
                    {
                        if (Parenthèses.Count == 0)
                            sb.Append('*');
                        char dernièreParenthèse = Parenthèses.Pop();
                        if (dernièreParenthèse != pair.Item1)
                            sb.Append('*');
                    }
                }
                sb.Append(c);
            }

            foreach (char c in parenthèses)
            {
                sb.Append('*');
            }

            parenthèses.Clear();
            
            return sb.ToString();
        }
    }
}