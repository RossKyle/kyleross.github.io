﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Exercice_StreamWriter
{
    class Program
    {
        public static void Main(string[] args)
        {
            string contenuFichier;
            using (StreamReader sr = new StreamReader("../../Test.cs"))
                contenuFichier = sr.ReadToEnd();
            
            DétecteurÉquilibreParenthèses détecteur = new DétecteurÉquilibreParenthèses();
            using (StreamWriter sw = new StreamWriter("../../sortie.log"))
                sw.Write(détecteur.Détecter(contenuFichier));
        }
    }
}
