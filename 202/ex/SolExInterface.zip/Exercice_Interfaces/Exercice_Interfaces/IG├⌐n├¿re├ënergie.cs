namespace Exercice_Interfaces
{
    public interface IGénèreÉnergie
    {
        float GénèreÉnergie();
    }
}