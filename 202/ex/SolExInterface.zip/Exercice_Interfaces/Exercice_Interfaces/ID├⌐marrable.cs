namespace Exercice_Interfaces
{
    public interface IDémarrable
    {
        bool EstDémarré { get; }
        void Démarrer();
    }
}