namespace Exercice_Interfaces
{
    public class MoteurCombustion : Moteur
    {
        public MoteurCombustion(string modèle)
            : base(modèle)
        {}

        public override float GénèreÉnergie()
        {
            return 16;
        }

        public override string ToString()
        {
            return base.ToString() + "\nCombustion";
        }
    }
}