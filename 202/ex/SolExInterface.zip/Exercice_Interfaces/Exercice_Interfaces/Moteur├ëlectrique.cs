namespace Exercice_Interfaces
{
    public class MoteurÉlectrique : Moteur
    {
        private float ampérageMaximum;

        public float AmpérageMaxium
        {
            get { return ampérageMaximum; }
            private set
            {
                if (value < 0)
                    value = 0;
                ampérageMaximum = value;
            }
        }
        public override float GénèreÉnergie()
        {
            return 10;
        }
        
        public MoteurÉlectrique(string modèle, float ampérage) : base(modèle)
        {
            AmpérageMaxium = ampérage;
        }

        public override string ToString()
        {
            return base.ToString() + "\nÉlectrique";
        }
    }
}