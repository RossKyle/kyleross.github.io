﻿using System;

namespace Exercice_Interfaces
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Moteur[] moteurs = new Moteur[]
            {
                new MoteurÉlectrique("SIMSUPREME", 500),
                new MoteurCombustion("GazmoéLine")
            };

            for (int i = 0; i < moteurs.Length; ++i)
            {
                var voitureActuelle = new Voiture(moteurs[i]);
                voitureActuelle.Démarrer();
                Console.WriteLine(voitureActuelle.ToString());
            }
        }
    }
}