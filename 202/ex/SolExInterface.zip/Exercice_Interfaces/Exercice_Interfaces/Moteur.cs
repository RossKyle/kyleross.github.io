using System;
using System.Globalization;

namespace Exercice_Interfaces
{
    public abstract class Moteur : IGénèreÉnergie, IDémarrable
    {
        private string modèle;
        private bool estDémarré;

        public string Modèle
        {
            get { return modèle; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException();
                modèle = value;
            }
        }
        public bool EstDémarré
        {
            get { return estDémarré; }
            private set { estDémarré = value; }
        }

        public void Démarrer()
        {
            EstDémarré = true;
        }

        public abstract float GénèreÉnergie();

        public Moteur(string modèle)
        {
            Modèle = modèle;
        }
        
        public override string ToString()
        {
            return $"{Modèle}";
        }
    }
}