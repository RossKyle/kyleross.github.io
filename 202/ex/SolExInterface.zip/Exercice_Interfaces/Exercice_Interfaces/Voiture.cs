using System;

namespace Exercice_Interfaces
{
    public class Voiture : IDémarrable
    {
        private bool estDémarré;
        private Moteur moteur;
        
        public bool EstDémarré
        {
            get { return estDémarré; }
            private set { estDémarré = value; }
        }

        private Moteur Moteur
        {
            get { return moteur; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException();
                moteur = value;
            }
        }

        public void Démarrer()
        {
            EstDémarré = true;
            Moteur.Démarrer();
        }

        public Voiture(Moteur moteur)
        {
            Moteur = moteur;
        }

        public override string ToString()
        {
            return $"Démarré? {EstDémarré}\nMoteur : {Moteur}";
        }
    }
}