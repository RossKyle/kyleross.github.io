﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
Par question, il faut ajouter qu'une seule ligne en utilisant une des méthodes LINQ suivantes :

.Where(...);
.Sum();
.Sum(...);
.Max();
.Max(...);
.Min();
.Min(...);
.Average();
.Average(...);
.Count();
.Count(...);
*/

namespace Exercice_1_Lambda
{
    class Program
    {
        const int ValMin = 1000;
        const int ValMax = 20000;
        const int NbVals = 20;

        static void Main(string[] args)
        {
            var liste = GénérerListe();
            AfficherListe(liste);
            TrouverSomme(liste);
            TrouverPlusGrand(liste);
            TrouverPlusPetit(liste);
            TrouverMoyenne(liste);
            TrouverStatistiquesPourValeursPlusGrandesQue(liste);
            Console.WriteLine();
        }

        /// Permet de trouver la somme des valeurs de la liste
        static void TrouverSomme(List<double> liste)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double somme = 0;

            Console.WriteLine($"La somme des valeurs de la liste est   : {somme:f2}");
        }

        /// Permet de trouver la plus grande des valeurs de la liste
        static void TrouverPlusGrand(List<double> liste)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double plusGrand = 0;

            Console.WriteLine($"La plus grande valeur de la liste est  : {plusGrand:f2}");
        }

        /// Permet de trouver la plus petite des valeurs de la liste
        static void TrouverPlusPetit(List<double> liste)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double plusPetit = 0;

            Console.WriteLine("La plus petite valeur de la liste est  : {0:f2}", plusPetit);
        }

        /// Permet de trouver la moyenne des valeurs de la liste
        static void TrouverMoyenne(List<double> liste)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double moyenne = 0;

            Console.WriteLine("La moyenne des valeurs de la liste est : {0:f2}", moyenne);
        }


        /// Permet de trouver le nombre de valeurs supérieures à un certain plancher
        static void TrouverNombreDeValeursPlusGrandesQue(List<double> liste, double valeur)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            int nombre = 0;

            Console.WriteLine("Le nombre de valeurs de la liste supérieures à {0:f2} est   : {1}", valeur, nombre);
        }

        /// Permet de trouver la somme des valeurs supérieures à un certain plancher
        static void TrouverSommeDesValeursPlusGrandesQue(List<double> liste, double valeur)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double somme = 0;

            Console.WriteLine("La somme des valeurs de la liste supérieures à {0:f2} est   : {1:f2}", valeur, somme);
        }

        /// Permet de trouver la moyenne des valeurs supérieures à un certain plancher
        static void TrouverMoyenneDesValeursPlusGrandesQue(List<double> liste, double valeur)
        {
            // --------- à MODIFIER par l'étudiant ------------------
            double moyenne = 0;

            Console.WriteLine("La moyenne des valeurs de la liste supérieures à {0:f2} est : {1:f2}", valeur, moyenne);
        }



        static void TrouverStatistiquesPourValeursPlusGrandesQue(List<double> liste)
        {
            double valeur;

            Console.WriteLine();
            Console.Write("Valeur plancher pour les statistiques des valeurs supérieures : ");
            valeur = double.Parse(Console.ReadLine());
            TrouverNombreDeValeursPlusGrandesQue(liste, valeur);
            TrouverSommeDesValeursPlusGrandesQue(liste, valeur);
            TrouverMoyenneDesValeursPlusGrandesQue(liste, valeur);
        }
        
        static List<double> GénérerListe()
        {
            // --- Ici, le Random (10) fait en sorte que les nombres tirés
            //     par le générateur sont toujours les mêmes, aux fins de 
            //     mise au point du programme. Vous pourrez modifier l'instanciation
            //     pour faire appel au constructeur par défaut lorsque votre programme
            //     sera complété. 
            Random générateur = new Random(10);
            List<double> liste = new List<double>();
            double valeurChoisie;

            for (int i = 0; i < NbVals; ++i)
            {
                // NextDouble retourne une valeur entre [0 et 1[
                valeurChoisie = (générateur.NextDouble() * (ValMax - ValMin) + ValMin);
                liste.Add(valeurChoisie);
            }
            return liste;
        }

        static void AfficherListe(List<double> liste)
        {
            const int NB_VALEURS_PAR_LIGNE = 5;
            string ligne = new string('-', 79);

            Console.WriteLine(ligne);
            for (int i = 0; i < liste.Count; ++i)
            {
                Console.Write(string.Format("{0:f4}", liste[i]).PadLeft(15));
                if ((i % NB_VALEURS_PAR_LIGNE) == (NB_VALEURS_PAR_LIGNE - 1))
                {
                    Console.WriteLine();
                }
            }
            Console.WriteLine(ligne);
        }
    }
}
