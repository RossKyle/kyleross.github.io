﻿using System;
using System.Collections.Generic;

namespace Exercice_CarteDeJeu
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Carte carteTest = new Carte(5, 4);
            carteTest.AjouterTypeTuile(6);
            Console.WriteLine($"Réussite d'ajouter un duplicat ? {carteTest.AjouterTypeTuile(6)}");
            carteTest[2, 3] = 6;
            AfficherCarte(carteTest);    
        }

        public static void AfficherCarte(Carte carteÀAfficher)
        {
            for (int i = 0; i < carteÀAfficher.NbLignes; ++i)
            {
                for (int j = 0; j < carteÀAfficher.NbColonnes; ++j)
                {
                    Console.Write(carteÀAfficher[i,j]) ;
                }
                Console.WriteLine();
            }
        }
    }
}