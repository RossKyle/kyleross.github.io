﻿// Une autruche est un oiseau qui s'engage à remplir les
// obligations imposées par l'interface INonVolant. 
//
// par Pierre Prud'homme, 2017
//----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    class Autruche: Oiseau, ITerrestre
    {
        const float VitsseMaxMarche = 3;  // km/h
        const float VitesseMaxCourse = 70; // km/h

        float vitesse;
        public float Vitesse 
        { 
            get 
            {
                return vitesse;
            }
            set
            {
                vitesse = value;
            }
        }

        public Autruche (int poids)
            :base(poids, "blanc")
        {
            Vitesse = 0;
        }
        
        public void Marcher()
        {
            Vitesse = VitsseMaxMarche;           
            Console.WriteLine($"Je suis l'autruche et je marche à {Vitesse} km/h");
        }
        
        public void Courir()
        {
            Vitesse = VitesseMaxCourse;           
            Console.WriteLine("Je suis l'autruche et je cours à {Vitsse} km/h");
        }
        
        public void Arreter()
        {
            Vitesse = 0; 
            Console.WriteLine("Je suis l'autruche et je m'arrête");
        }
    }
}
