﻿using System;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    class Moustique : Insecte, IVolant
    {
        private bool estEnVol;

        public bool EstEnVol
        {
            get { return estEnVol; }
            private set { estEnVol = value; }
        }

        public Moustique(int poids)
            :base(poids, false)
        {
            EstEnVol = false;
        }

        public void Décoller()
        {
            if (!EstEnVol)
            {
                EstEnVol = true;
                Console.WriteLine("Ce moustique s'envole... ");
            }
        }
        
        public void SePoser()
        {
            if (EstEnVol)
            {
                EstEnVol = false;
                Console.WriteLine("Ce moustique se pose...");
            }
        }
    }
}
