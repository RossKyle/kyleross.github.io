﻿// Une coquerelle est un insecte qui s'engage à remplir les
// obligations imposées par l'interface INonVolant. 
//
// par Pierre Prud'homme, 2017
//----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    class Coquerelle : Insecte, ITerrestre
    {
        const float VitesseMaxMarche = 0.5f;  // km/h
        const float VitesseMaxCourse = 1; // km/h

        float vitesse;
        public float Vitesse 
        { 
            get 
            {
                return vitesse;
            }
            set
            {
                vitesse = value;
            }
        }

        public Coquerelle (int poids)
            :base(poids, true)
        {
            Vitesse = 0;
        }
        
        public void Marcher()
        {
            Vitesse = VitesseMaxMarche;           
            Console.WriteLine("Je suis une coquerelle et je marche à {0} km/h", Vitesse);
        }
        
        public void Courir()
        {
            Vitesse = VitesseMaxCourse;           
            Console.WriteLine("Je suis une coquerelle et je cours à {0} km/h", Vitesse);
        }
        
        public void Arreter()
        {
            Vitesse = 0; 
            Console.WriteLine("Je suis une coquerelle et je m'arrête");
        }
    }
}
