﻿// Interface IVolant pour tous les animaux qui volent
//
// par Pierre Prud'homme, 2017
//----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    interface IVolant
    {	
        void Décoller();
        void SePoser();
       
        bool EstEnVol { get; }
    }
}
