﻿using System;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    class Hirondelle : Oiseau, IVolant
    {
        public bool EstEnVol {get; private set;}
        
        public Hirondelle(int poids)
            :base(poids, "bleu")
        {
            EstEnVol = false;
        }

        public void Décoller()
        {
            if (! EstEnVol)
            {
                EstEnVol = true;
                Console.WriteLine("Cette hirondelle s'envole... ");
            }
        }
        
        public void SePoser()
        {
            if (EstEnVol)
            {
                EstEnVol = false;
                Console.WriteLine("Cette hirondelle se pose...");
            }
        }
    }
}
