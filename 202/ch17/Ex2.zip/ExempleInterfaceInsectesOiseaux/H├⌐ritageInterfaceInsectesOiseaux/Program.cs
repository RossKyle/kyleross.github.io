﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> lesAnimaux = new List<Animal>();

            lesAnimaux.Add(new Coquerelle(2));
            lesAnimaux.Add(new Coquerelle(1));
            lesAnimaux.Add(new Hirondelle(125));
            lesAnimaux.Add(new Autruche(80500));
            lesAnimaux.Add(new Moustique(1));

            // Ici, on peut isoler dans une nouvelle liste les animaux
            // qui ont implanté l'interface IVolant. On rassemble donc des
            // insectes et des oiseaux en fonction du fait qu'ils peuvent
            // voler et ont tous les comportements prévus à l'interface.
            List<IVolant> listeVolants = lesAnimaux.OfType<IVolant>().ToList();

            foreach(IVolant v in listeVolants)
            {
                // tous les animaux qui volent décollent 
                v.Décoller();
            }

            // L'appel de Sort va utiliser la méthode CompareTo qui a été
            // écrite pour implanter l'interface IComparable. 
            lesAnimaux.Sort();

            Console.WriteLine();
            foreach (Animal a in lesAnimaux)
            {
                Console.Write(a.ToString() + " a un poids de ");
                Console.WriteLine(a.Poids);
            }

        }
    }
}
