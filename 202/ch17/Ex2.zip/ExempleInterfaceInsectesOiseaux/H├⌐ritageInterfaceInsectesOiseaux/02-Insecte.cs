﻿namespace _13_HéritageInterfaceOiseauxInsectes
{
    abstract class Insecte : Animal
    {
        bool aUneCarapace;
        
        public bool AUneCarapace
        {
            get
            {
                return aUneCarapace;
            }
            private set
            {
                aUneCarapace = value;
            }
        }

        public Insecte(int poids, bool aUneCarapace)
            :base(poids)
        {
            AUneCarapace = aUneCarapace;
        }
    }
}
