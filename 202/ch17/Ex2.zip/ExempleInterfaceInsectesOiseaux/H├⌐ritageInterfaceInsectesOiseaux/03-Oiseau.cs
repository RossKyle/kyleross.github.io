﻿namespace _13_HéritageInterfaceOiseauxInsectes
{
    abstract class Oiseau : Animal
    {
        string couleur;
        public string Couleur
        {
            get
            {
                return couleur;
            }
            private set
            {
                couleur = value;
            }
        }

        public Oiseau(int poids, string couleur)
            :base(poids)
        {
            Couleur = couleur;
        }
    }
}
