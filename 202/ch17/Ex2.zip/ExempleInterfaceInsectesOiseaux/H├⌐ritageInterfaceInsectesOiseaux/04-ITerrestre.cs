﻿// Interface INonVolant pour tous les animaux qui ne 
// volent pas
//
// par Pierre Prud'homme, 2017
//----------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    interface ITerrestre
    {
        void Marcher();
        void Courir();
        void Arreter();
        
        //Un private set peut être ajouté dans les classes qui ont la qualité d'être terrestre
        float Vitesse { get; }
    }
}
