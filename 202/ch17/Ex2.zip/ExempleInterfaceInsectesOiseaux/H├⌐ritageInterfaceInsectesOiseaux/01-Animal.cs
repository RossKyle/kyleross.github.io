﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _13_HéritageInterfaceOiseauxInsectes
{
    abstract class Animal : IComparable
    {	
        int poids;
        public int Poids
        {
            get
            {
                return poids;
            }
            private set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException();
                poids = value;
            }
        }

        public Animal(int poids)
        {
            Poids = poids;
        }

        public int CompareTo(object obj)
        {
            return Poids.CompareTo(((Animal) obj).Poids);
        }
    }
}
