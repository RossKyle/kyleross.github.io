﻿using System;

namespace ConsoleApplication2
{
    class Don : IComparable
    {
        string noDonateur;
        int année;
        float montant;

        public string NoDonateur
        {
            get
            {
                return noDonateur;
            }
            private set
            {
                noDonateur = value;
            }
        }

        public int Année
        {
            get
            {
                return année;
            }
            private set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException();
                année = value;
            }
        }

        public float Montant
        {
            get
            {
                return montant;
            }
            private set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException();
                montant = value;
            }
        }

        public Don(string noDonateur, int année, float montant)
        {
            NoDonateur = noDonateur;
            Année = année;
            Montant = montant;
        }

        public override string ToString()
        {
            return $"NoDonateur : {NoDonateur}, Année : {Année},  Montant : {Montant:c2}";
        }

        public int CompareTo(object obj)
        {
            Don d = obj as Don;
            //Montant est un float; le type float implante l'interface IComparable, donc tous float ont une méthode .CompareTo
            //Pour un float, CompareTo retourne 1 si la valeur numérique en paramètre est plus petite, 0 si égal ou -1 si plus grande
            return Montant.CompareTo(d.Montant);

            //Plus long
            /*if (Montant > d.Montant)
                return 1;
            else if (Montant == d.Montant)
                return 0;
            else
                return -1*/
        }
    }
}
