﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Don d1 = new Don("UL-420", 2016, 50);
            Don d2 = new Don("XY-99", 2017, 25);

            if (d1.CompareTo(d2) == 1)
                Console.WriteLine("d1 est un plus grand don que d2");
            
            List<Don> dons = new List<Don>(){d1, d2};

            //Un appel à Sort sans paramètre va utiliser le CompareTo défini pour le type d'élément dans la liste.
            //Bref, si nous disons qu'un type est comparable, il est nécessairement triable ! 
            //C# peut trier tous les types qui sont IComparable
            dons.Sort(); 
            foreach(Don d in dons)
            {
                Console.WriteLine(d);
            }
        }
    }
}
