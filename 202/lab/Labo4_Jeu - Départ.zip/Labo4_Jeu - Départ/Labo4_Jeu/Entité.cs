using System;
using System.Collections.Generic;
using SFML.Graphics;
using SFML.System;

//À COMPLÉTER
namespace Labo4_Jeu
{
    public class Entité : Drawable //complétez cette ligne
    {
        //complétez la classe
        //ne touchez pas à la méthode Draw

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Transform = Transform.Identity;
            states.Transform.Translate(Position.X * 64, Position.Y * 64);
            target.Draw(SpriteÀDessiner, states);
        }
    }
}