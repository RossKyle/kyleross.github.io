using SFML.Graphics;
using SFML.System;

//À COMPLÉTER
namespace Labo4_Jeu
{
    public class Patineur  //complétez cette ligne
    {
        //complétez la classe
    }
}