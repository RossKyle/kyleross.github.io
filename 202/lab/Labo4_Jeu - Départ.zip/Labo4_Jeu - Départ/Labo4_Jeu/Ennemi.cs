using System;
using SFML.Graphics;
using SFML.System;

//À COMPLÉTER
namespace Labo4_Jeu
{
    public class Ennemi //complétez cette ligne
    {
        //complétez la classe
    }
}