using System;
using SFML.Graphics;
using SFML.System;

//À COMPLÉTER
namespace Labo4_Jeu
{
    public class Guerrier //complétez cette ligne
    {
        //complétez la classe
    }
}