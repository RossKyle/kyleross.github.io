namespace LibJeux
{
    public class Item
    {
    }
}
