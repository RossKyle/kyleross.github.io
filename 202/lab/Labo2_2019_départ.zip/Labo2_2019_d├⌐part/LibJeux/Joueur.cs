namespace LibJeux
{
    public class Joueur
    {
    }
}
