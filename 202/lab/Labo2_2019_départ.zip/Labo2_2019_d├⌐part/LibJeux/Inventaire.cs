namespace LibJeux
{
    public class Inventaire
    {
    }
}
