﻿namespace LibJeux
{
    public class Vecteur3
    {
    }
}
