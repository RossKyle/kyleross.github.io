﻿using LibJeux;

namespace TestsLibJeux
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Vecteur3 v;
            Item i;
            Inventaire inv;
            Joueur j;
        }
    }
}