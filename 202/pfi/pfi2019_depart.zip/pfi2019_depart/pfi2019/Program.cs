﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace pfi2019
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //TesterNoeud();
            //TesterGraphe();
            
            Console.ReadKey();
        }

        static void TesterNoeud()
        {
            TestsNoeud.Test1();
            TestsNoeud.Test2();
            TestsNoeud.Test3();
            TestsNoeud.Test4();
            TestsNoeud.Test5();
            TestsNoeud.Test6();
        }

        /*
        static void TesterGraphe()
        {
            CréerScène(TestsGraphe.Test1());
            CréerScène(TestsGraphe.Test2());
            TestsGraphe.Test3();
            CréerScène(TestsGraphe.Test4());
            CréerScène(TestsGraphe.Test5());
        }
        */

        /*
        static void CréerScène(Graphe graphe)
        {
            RenderWindow fenêtre = new RenderWindow(new VideoMode(1280, 720),
                "PFI", Styles.Default, new ContextSettings(){AntialiasingLevel = 8});
            fenêtre.Clear(Color.White);
            fenêtre.Draw(graphe);
            fenêtre.Display();
        }
        */
    }
}