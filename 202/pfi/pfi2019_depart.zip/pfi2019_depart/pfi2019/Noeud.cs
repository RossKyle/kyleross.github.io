using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SFML.Graphics;
using SFML.System;

namespace pfi2019
{
    public class Noeud //complété cette ligne
    

        public void Draw(RenderTarget target, RenderStates states)
        {
            var texte = new Text(Étiquette, GestionnaireRessources.PolicePrincipale, 50);
            texte.FillColor = Color.White;
            texte.Origin = new Vector2f(-33, -19);

            states.Transform = Transform.Identity;
            states.Transform.Translate(Position.X, Position.Y);
            var cercle = new CircleShape(50, 150);
            cercle.FillColor = Color.Black;


            target.Draw(cercle, states);
            target.Draw(texte, states);
        }


        public override bool Equals(object obj)
        {
            return Étiquette == ((Noeud) obj)?.Étiquette;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}