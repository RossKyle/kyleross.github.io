﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    class PrismeRectangulaire : Forme3D
    {
        public override float Aire
        {
            get { return (Longueur * Hauteur) * NbFaces; }
        }

        public override float Volume
        {
            get { return (Longueur * Hauteur) * Hauteur; }
        }

        public PrismeRectangulaire(int longueur, int hauteur, int largeur)
            : base(longueur, hauteur, largeur, 6)
        {
        }

        public override void Afficher()
        {
            string espacesCarré = new string(' ', Longueur * 2 + 2);
            string bordureHorizontaleCarré = new string('═', Longueur * 2 + 2);
            int demiHauteur = Hauteur / 2;
            string espacesLargeur = new string(' ', Largeur / 2);
            StringBuilder builder = new StringBuilder(100);
            //Le bloc ci-HAUT n'est pas super, 
            //si nous supposons que nous allons régulièrement afficher un cube, 
            //car à chaque fois que nous voulons afficher, nous recréons les mêmes données
            //(espaceCarré va toujours être pareil, car la largeur ne peut pas changer, par exemple)

            builder.AppendLine($" {espacesLargeur}{Symbole}{bordureHorizontaleCarré}{Symbole}");
            for (int i = Largeur /2; i > 0; i--)
                builder.AppendLine($"{new string(' ', i)}/{espacesCarré}/{new string(' ', Largeur/2 - i)}║");

            builder.AppendLine($"{Symbole}{bordureHorizontaleCarré}{Symbole}{espacesLargeur}║");
            for (int i = Hauteur - Largeur / 2 - 1; i > 0; i--)
                builder.AppendLine($"║{espacesCarré}║{espacesLargeur}║");
            builder.AppendLine($"║{espacesCarré}║{espacesLargeur}{Symbole}");
            for (int i = Largeur/2; i > 0; i--)
                builder.AppendLine($"║{espacesCarré}║{new string(' ', i - 1)}/");
            builder.AppendLine($"{Symbole}{bordureHorizontaleCarré}{Symbole}");

            Console.WriteLine(builder);
        }
    }
}
