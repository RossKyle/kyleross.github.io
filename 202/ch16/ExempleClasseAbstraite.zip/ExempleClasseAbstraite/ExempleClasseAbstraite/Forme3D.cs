﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    abstract class Forme3D : FormeNonUnidimensionnelle
    {
        const char SymboleDéfaut = '+';

        int largeur;
        int nbFaces;

        public int Largeur
        {
            get { return largeur; }
            private set
            {
                if (value < 1)
                    value = 1;
                largeur = value;
            }
        }

        public int NbFaces
        {
            get { return nbFaces; }
            private set
            {
                if (value < 1)
                    value = 1;
                nbFaces = value;
            }
        }

        abstract public float Volume { get; }
  
        public Forme3D(int longueur, int hauteur, int largeur, int nbFaces) 
            : base(longueur, hauteur, '+')
        {
            Largeur = largeur;
            NbFaces = nbFaces;
        }   
    }
}
