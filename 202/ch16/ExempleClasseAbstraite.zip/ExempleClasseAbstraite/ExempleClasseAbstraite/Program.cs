﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    class Program
    {
        static void Main(string[] args)
        {
            FormeNonUnidimensionnelle uneForme = new PrismeRectangulaire(4, 8, 10);
            uneForme.Afficher();

            FormeNonUnidimensionnelle uneForme2 = new PrismeRectangulaire(20, 4, 2);
            uneForme2.Afficher();

            Forme3D uneForme3D = new Cube(6);
            uneForme3D.Afficher();
            Console.WriteLine("Volume du cube 6x6x6 : " + uneForme3D.Volume);
        }
    }
}
