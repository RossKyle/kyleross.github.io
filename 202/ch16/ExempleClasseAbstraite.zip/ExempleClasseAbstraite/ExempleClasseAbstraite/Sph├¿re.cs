﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    class Sphère : Forme3D
    {
        public int Rayon
        {
            get { return Largeur / 2; }
        }

        public override float Volume
        {
            get { return Aire * Rayon / 3; }
        }

        public override float Aire
        {
            get { return (float)(4 * Math.PI * Math.Pow(Rayon, 2)); }
        }

        public Sphère(int rayon) : base(rayon * 2, rayon * 2, rayon * 2, 1) {}

        public override void Afficher()
        {
            throw new NotImplementedException("pas encore fait...");
        }
    }
}
