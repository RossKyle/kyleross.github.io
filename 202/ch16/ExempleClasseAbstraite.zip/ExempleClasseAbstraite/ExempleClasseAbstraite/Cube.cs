﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    class Cube : PrismeRectangulaire
    {
        public Cube(int longueurCôté) : base(longueurCôté, longueurCôté, longueurCôté) {} 
    }
}
