﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExempleClasseAbstraite
{
    abstract class FormeNonUnidimensionnelle //classe contient une méthode abstraite
    {
        int longueur;
        int hauteur;
        char symbole;
        public int Longueur
        {
            get { return longueur; }
            private set //appelé une seule fois dans le constructeur
                        //Les instances de classes dérivées ne peuvent changer de largeur
            {
                if (value < 1)
                    value = 1;
                longueur = value;
            }
        }

        public int Hauteur
        {
            get { return hauteur; }
            private set //appelé une seule fois dans le constructeur
                        //Les instances de classes dérivées ne peuvent changer d'hauteur
            {
                if (value < 1)
                    value = 1;
                hauteur = value;
            }
        }

        public char Symbole
        {
            get { return symbole; }
            protected set //les classes dérivées ont accès à faire Symbole = X
            {
                if (value == ' ' || value == '\n')
                    throw new ArgumentException("symbole pour afficher une forme ne peut être un espace ou saut de ligne");

                symbole = value;
            }
        }

        //toutes formes a un aire, qu'il soit 2D ou 3D, 
        //mais le calcul de l'aire doit être défini pour chaque sorte de forme spécialisée 
        //(nous ne calculons pas l'aire de la même façon entre un rectangle et triangle, par exemple)
        abstract public float Aire { get; }

        public FormeNonUnidimensionnelle (int longueur, int hauteur, char symbole)
        { 
            Longueur = longueur;
            Hauteur = hauteur;
            Symbole = symbole;
        }

        //toutes formes peut s'afficher, mais impossible de définir comment dans cette classe, 
        //car ce n'est pas toutes formes qui s'affichent pareillement 
        //(le code pour afficher un rectangle va être différent de celui pour un triangle, par exemple)
        abstract public void Afficher(); 
    }
}
