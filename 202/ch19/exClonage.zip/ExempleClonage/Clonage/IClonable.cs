namespace Clonage
{
    public interface IClonable<T>
    {
        T Clone();
    }
}