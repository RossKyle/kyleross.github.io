using System.Collections.Generic;

namespace Exercice_CarteDeJeu
{
    public class Carte
    {
        private const int NbLignesDéfaut = 5;
        private const int NbColonnesDéfaut = 5;
        
        private int[,] tuiles;
        private int nbLignes;
        private int nbColonnes;
        private List<int> typesTuile;
        private int[,] Tuiles
        {
            get { return tuiles; }
            set { tuiles = value; }
        }

        public int this[int i, int j]
        {
            get { return Tuiles[i, j]; }
            set
            {
                if (TypesTuile.Contains(value))
                    Tuiles[i, j] = value;
            }
        }

        public int NbLignes
        {
            get { return nbLignes; }
            private set
            {
                if (value < 0)
                    value = 1;
                nbLignes = value;
            }
        }

        public int NbColonnes
        {
            get { return nbColonnes; }
            private set
            {
                if (value < 1)
                    value = 1;
                nbColonnes = value;
            }
        }

        private List<int> TypesTuile
        {
            get { return typesTuile; }
            set { typesTuile = value; }
        }
        
        public int NbTypesTuile
        {
            get { return TypesTuile.Count; }
        }
        
        public Carte(int nbLignesInit, int nbColonneInit)
        {
            TypesTuile = new List<int>(4) {0};
            Tuiles = new int[nbLignesInit, nbColonneInit];
            NbLignes = nbLignesInit;
            NbColonnes = nbColonneInit;
        }
        
        public Carte()
            :this(NbLignesDéfaut, NbColonnesDéfaut){}

        public bool AjouterTypeTuile(int nouveauType)
        {
            bool opérationSuccès;
            if (opérationSuccès = !TypesTuile.Contains(nouveauType)) //raccourci pour affecter la variable et faire le test du if
                TypesTuile.Add(nouveauType);
            
            return opérationSuccès;
        }
    }
}